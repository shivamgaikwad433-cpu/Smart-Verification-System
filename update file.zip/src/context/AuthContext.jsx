import React, { createContext, useContext, useState, useEffect } from 'react';
import { authApi } from '../api/authApi';
import { setAuthToken, getAuthToken } from '../api/axiosClient';
import { mockUsers } from '../api/mockData';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [token, setTokenState] = useState(() => getAuthToken());
  const [user, setUser] = useState(() => {
    const savedUser = sessionStorage.getItem('scv_user');
    return savedUser ? JSON.parse(savedUser) : null;
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (token) {
      setAuthToken(token);
    }
  }, [token]);

  const login = async (email, password) => {
    setLoading(true);
    try {
      const response = await authApi.login(email, password);
      const authToken = response.token;
      const authUser = response.user;

      setTokenState(authToken);
      setUser(authUser);
      sessionStorage.setItem('scv_user', JSON.stringify(authUser));

      return { success: true, role: authUser.role };
    } catch (error) {
      return { success: false, message: error.message || 'Login failed' };
    } finally {
      setLoading(false);
    }
  };

  const lookupEmail = async (email) => {
    return await authApi.lookupByEmail(email);
  };

  const verifyFaceForEmail = async (email, faceImage) => {
    setLoading(true);
    try {
      const response = await authApi.verifyFaceForEmail(email, faceImage);
      if (response.isAllowed && response.token) {
        setTokenState(response.token);
        setUser(response.user);
        sessionStorage.setItem('scv_user', JSON.stringify(response.user));
      }
      return response;
    } catch (error) {
      return {
        isAllowed: false,
        message: error.message || 'Face recognition matching failed',
      };
    } finally {
      setLoading(false);
    }
  };


  const registerWithFace = async (userData) => {
    setLoading(true);
    try {
      const response = await authApi.registerWithFace(userData);
      if (response?.token && response?.user) {
        setTokenState(response.token);
        setUser(response.user);
        sessionStorage.setItem('scv_user', JSON.stringify(response.user));
      }
      return response;
    } catch (error) {
      return { success: false, message: error.message || 'Registration failed' };
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    authApi.logout();
    setTokenState(null);
    setUser(null);
    sessionStorage.removeItem('scv_user');
  };

  // Helper function to quickly switch role for demo/testing purposes
  const switchRole = (newRole) => {
    const matched = mockUsers.find((u) => u.role === newRole) || {
      id: 'demo_' + newRole,
      name: `Demo ${newRole.toUpperCase()} User`,
      email: `${newRole}@campus.edu`,
      role: newRole,
      prn: newRole === 'student' ? 'PRN202401088' : undefined,
      department: 'Campus Administration',
      status: 'Active',
    };
    setUser(matched);
    sessionStorage.setItem('scv_user', JSON.stringify(matched));
  };

  return (
    <AuthContext.Provider
      value={{
        token,
        user,
        role: user?.role || null,
        isAuthenticated: !!token && !!user,
        loading,
        login,
        lookupEmail,
        verifyFaceForEmail,
        registerWithFace,
        logout,
        switchRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};


export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
