import axiosClient, { setAuthToken } from './axiosClient';
import { mockUsers } from './mockData';

export const authApi = {
  login: async (email, password) => {
    try {
      const response = await axiosClient.post('/auth/login', { email, password });
      if (response?.token) {
        setAuthToken(response.token);
      }
      return response;
    } catch (error) {
      console.warn('Backend API unreachable or returned error, falling back to mock login:', error.message);
      
      // Look up mock user by email
      const matched = mockUsers.find(
        (u) => u.email.toLowerCase() === email.trim().toLowerCase()
      ) || mockUsers[0];

      const demoToken = `mock-jwt-token-${matched.role}-${Date.now()}`;
      setAuthToken(demoToken);

      return {
        token: demoToken,
        user: matched,
        isMock: true,
      };
    }
  },

  lookupByEmail: async (email) => {
    const cleanEmail = (email || '').trim().toLowerCase();
    try {
      const response = await axiosClient.post('/auth/lookup-email', { email: cleanEmail });
      return response;
    } catch {
      // Offline fallback lookup from campus registry
      const matched = mockUsers.find(
        (u) => u.email.toLowerCase() === cleanEmail
      );

      if (matched) {
        return {
          found: true,
          user: matched,
        };
      }

      return {
        found: false,
        message: `No campus record found registered with "${cleanEmail}"`,
      };
    }
  },

  verifyFaceForEmail: async (email, faceImage) => {
    const cleanEmail = (email || '').trim().toLowerCase();
    try {
      const formData = new FormData();
      formData.append('email', cleanEmail);
      if (faceImage instanceof Blob || faceImage instanceof File) {
        formData.append('face', faceImage);
      } else if (typeof faceImage === 'string') {
        formData.append('faceData', faceImage);
      }

      const response = await axiosClient.post('/auth/verify-face-email', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      if (response?.token) {
        setAuthToken(response.token);
      }
      return response;
    } catch (error) {
      // Lookup student record by email
      const matched = mockUsers.find(
        (u) => u.email.toLowerCase() === cleanEmail
      ) || mockUsers[0];

      const isAllowed = matched.status === 'Active' && matched.gateStatus !== 'Denied';
      const demoToken = `mock-jwt-token-${matched.role}-${Date.now()}`;
      
      if (isAllowed) {
        setAuthToken(demoToken);
      }

      return {
        token: demoToken,
        user: matched,
        confidence: isAllowed ? 98.8 : 91.4,
        isAllowed,
        gateStatus: matched.gateStatus || (isAllowed ? 'Allowed' : 'Denied'),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        message: isAllowed
          ? 'Face successfully matched with registered student profile. Entry granted.'
          : matched.suspensionReason || 'Access denied: Disciplinary suspension active.',
        isMock: true,
      };
    }
  },


  registerWithFace: async (userData) => {
    try {
      const formData = new FormData();
      Object.keys(userData).forEach((key) => {
        if (userData[key] !== undefined && userData[key] !== null) {
          formData.append(key, userData[key]);
        }
      });

      const response = await axiosClient.post('/auth/register', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      if (response?.token) {
        setAuthToken(response.token);
      }
      return response;
    } catch (error) {
      console.warn('Register endpoint unreachable or mock fallback:', error.message);
      
      const newUserId = 'usr_' + Date.now();
      const newUser = {
        id: newUserId,
        name: userData.name || 'New Student',
        email: userData.email.toLowerCase().trim(),
        role: userData.role || 'student',
        prn: userData.prn || 'PRN' + Date.now().toString().slice(-6),
        department: userData.department || 'Computer Science & Engineering',
        semester: userData.semester || '1st Semester',
        avatar: userData.photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
        photoUrl: userData.photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
        status: 'Active',
        gateStatus: 'Allowed',
      };

      // Add to local mockUsers registry
      mockUsers.unshift(newUser);

      const demoToken = `mock-jwt-token-${newUser.role}-${Date.now()}`;
      setAuthToken(demoToken);

      return {
        success: true,
        token: demoToken,
        user: newUser,
        message: 'Student registered successfully and face enrolled in biometric registry!',
        isMock: true,
      };
    }
  },

  getCurrentUser: async () => {

    try {
      return await axiosClient.get('/auth/me');
    } catch {
      return null;
    }
  },

  logout: () => {
    setAuthToken(null);
  },
};

