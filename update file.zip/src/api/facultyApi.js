import axiosClient from './axiosClient';
import { mockFacultyData } from './mockData';

export const facultyApi = {
  getClasses: async () => {
    try {
      return await axiosClient.get('/faculty/classes');
    } catch {
      return mockFacultyData.classes;
    }
  },

  detectAttendance: async (classId, photoFile) => {
    try {
      const formData = new FormData();
      formData.append('classId', classId);
      if (photoFile) {
        formData.append('photo', photoFile);
      }
      return await axiosClient.post('/faculty/attendance/detect', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
    } catch {
      // Return realistic recognition matches
      return {
        detectedCount: mockFacultyData.sampleDetectedMatches.length,
        matches: mockFacultyData.sampleDetectedMatches,
      };
    }
  },

  submitAttendance: async (payload) => {
    try {
      return await axiosClient.post('/faculty/attendance/submit', payload);
    } catch {
      return {
        success: true,
        attendanceId: 'ATT-' + Date.now().toString().slice(-6),
        message: 'Attendance recorded successfully',
      };
    }
  },

  getHistory: async () => {
    try {
      return await axiosClient.get('/faculty/attendance/history');
    } catch {
      return mockFacultyData.history;
    }
  },
};
