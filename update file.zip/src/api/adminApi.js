import axiosClient from './axiosClient';
import { mockAdminData } from './mockData';

// Local cache for mutated mock data
let localAdminData = { ...mockAdminData };

export const adminApi = {
  getStats: async () => {
    try {
      return await axiosClient.get('/admin/stats');
    } catch {
      return localAdminData.stats;
    }
  },

  getPlacements: async () => {
    try {
      return await axiosClient.get('/admin/placements');
    } catch {
      return localAdminData.placements;
    }
  },

  createPlacement: async (payload) => {
    try {
      return await axiosClient.post('/admin/placements', payload);
    } catch {
      const newDrive = {
        id: 'plc_' + Date.now(),
        ...payload,
        applicantsCount: 0,
        status: 'Open',
      };
      localAdminData.placements = [newDrive, ...localAdminData.placements];
      return newDrive;
    }
  },

  deletePlacement: async (id) => {
    try {
      return await axiosClient.delete(`/admin/placements/${id}`);
    } catch {
      localAdminData.placements = localAdminData.placements.filter((p) => p.id !== id);
      return { success: true };
    }
  },

  getClubs: async () => {
    try {
      return await axiosClient.get('/admin/clubs');
    } catch {
      return localAdminData.clubs;
    }
  },

  createClub: async (payload) => {
    try {
      return await axiosClient.post('/admin/clubs', payload);
    } catch {
      const newClub = {
        id: 'clb_' + Date.now(),
        ...payload,
        memberCount: 1,
        status: 'Active',
      };
      localAdminData.clubs = [newClub, ...localAdminData.clubs];
      return newClub;
    }
  },

  deleteClub: async (id) => {
    try {
      return await axiosClient.delete(`/admin/clubs/${id}`);
    } catch {
      localAdminData.clubs = localAdminData.clubs.filter((c) => c.id !== id);
      return { success: true };
    }
  },

  getUsers: async () => {
    try {
      return await axiosClient.get('/admin/users');
    } catch {
      return localAdminData.users;
    }
  },

  updateUserRole: async (userId, role) => {
    try {
      return await axiosClient.put(`/admin/users/${userId}`, { role });
    } catch {
      localAdminData.users = localAdminData.users.map((u) =>
        u.id === userId ? { ...u, role } : u
      );
      return { success: true };
    }
  },
};
