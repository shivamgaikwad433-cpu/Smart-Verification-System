import axiosClient from './axiosClient';
import { mockStudentData } from './mockData';

// Get the currently logged-in user from sessionStorage
const getLoggedInUser = () => {
  try {
    const saved = sessionStorage.getItem('scv_user');
    return saved ? JSON.parse(saved) : null;
  } catch {
    return null;
  }
};

export const studentApi = {
  getDashboardData: async () => {
    try {
      const response = await axiosClient.get('/student/dashboard');
      return response;
    } catch {
      // Use logged-in user's real info instead of hardcoded mock
      const loggedInUser = getLoggedInUser();
      if (loggedInUser) {
        return {
          ...mockStudentData,
          profile: {
            ...mockStudentData.profile,
            name: loggedInUser.name || mockStudentData.profile.name,
            email: loggedInUser.email || mockStudentData.profile.email,
            prn: loggedInUser.prn || mockStudentData.profile.prn,
            department: loggedInUser.department || mockStudentData.profile.department,
            semester: loggedInUser.semester || mockStudentData.profile.semester,
            photoUrl: loggedInUser.photoUrl || loggedInUser.avatar || mockStudentData.profile.photoUrl,
            status: loggedInUser.status || mockStudentData.profile.status,
            digitalId: loggedInUser.digitalId || ('SCV-STD-' + (loggedInUser.id || '').slice(-4).toUpperCase()) || mockStudentData.profile.digitalId,
          },
        };
      }
      return mockStudentData;
    }
  },

  getPlacements: async () => {
    try {
      return await axiosClient.get('/placements');
    } catch {
      return mockStudentData.placements;
    }
  },

  applyForPlacement: async (id) => {
    try {
      return await axiosClient.post(`/placements/${id}/apply`);
    } catch {
      // Mock update
      const drive = mockStudentData.placements.find((p) => p.id === id);
      if (drive) drive.hasApplied = true;
      return { success: true, message: 'Application submitted successfully' };
    }
  },

  getClubs: async () => {
    try {
      return await axiosClient.get('/clubs');
    } catch {
      return mockStudentData.clubs;
    }
  },

  registerForClub: async (id) => {
    try {
      return await axiosClient.post(`/clubs/${id}/register`);
    } catch {
      const club = mockStudentData.clubs.find((c) => c.id === id);
      if (club) club.isRegistered = true;
      return { success: true, message: 'Registration confirmed' };
    }
  },

  getNotifications: async () => {
    try {
      return await axiosClient.get('/notifications');
    } catch {
      return mockStudentData.notifications;
    }
  },
};
