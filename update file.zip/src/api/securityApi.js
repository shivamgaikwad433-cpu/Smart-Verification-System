import axiosClient from './axiosClient';
import { mockSecurityRegistry } from './mockData';

export const securityApi = {
  verifyStudent: async (identifier) => {
    const cleanId = (identifier || '').trim().toUpperCase();
    try {
      return await axiosClient.post('/security/verify', { prn: cleanId });
    } catch {
      // Lookup in fallback registry
      const record = mockSecurityRegistry[cleanId];
      if (record) {
        return {
          verified: true,
          student: record,
        };
      }

      // Check if it looks like a valid PRN format for demo
      if (cleanId.startsWith('PRN') || cleanId.length >= 6) {
        return {
          verified: true,
          student: {
            name: 'Student ID ' + cleanId,
            prn: cleanId,
            department: 'General Engineering',
            semester: 'Current',
            photoUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300&auto=format&fit=crop&q=80',
            status: 'Active',
            gateStatus: 'Allowed',
            notes: 'Standard ID verification confirmed.',
          },
        };
      }

      return {
        verified: false,
        student: null,
        message: 'No student record found for this PRN or scan.',
      };
    }
  },
};
